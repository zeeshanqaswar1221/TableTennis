using Fusion;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public TextMeshProUGUI RTT;

    void Update()
    {
        //print(Simulation.Statistics.NetStats.RoundTripTime);
    }
}
