using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IReset
{
    void Reset(Vector3 resetPos);
}
